#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."

echo "=== COMP3810SEF Campus Lost & Found: environment check ==="

if ! command -v node >/dev/null 2>&1; then
  echo "Error: node not found. Install Node.js 20 or newer."
  exit 1
fi

if ! command -v npm >/dev/null 2>&1; then
  echo "Error: npm not found. Install Node.js 20 or newer."
  exit 1
fi

NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]')"

if [ "$NODE_MAJOR" -lt 20 ]; then
  echo "Error: Node.js $(node -v) is too old, version 20 or newer is required."
  exit 1
fi

echo "Installing npm dependencies..."
npm install

echo "Creating / updating the demo accounts..."
npm run seed

echo "Checking the application and the database..."
npm run check

echo
echo "Done. Run npm start and open http://127.0.0.1:3000/"
