const User = require("../models/User");

const { setFlash } = require("./flash");

function wantsJson(req) {
  return (
    req.originalUrl.startsWith("/api/") ||
    req.is("application/json") ||
    req.accepts(["html", "json"]) === "json"
  );
}

async function loadUser(req, res, next) {
  if (!req.session || !req.session.userId) {
    return next();
  }

  try {
    const user = await User.findById(req.session.userId);

    if (!user || !user.isActive) {
      delete req.session.userId;
      req.user = null;
      return next();
    }

    req.user = user;
    next();
  } catch (error) {
    next(error);
  }
}

function requireAuth(req, res, next) {
  if (req.user) {
    return next();
  }

  if (wantsJson(req)) {
    return res.status(401).json({
      message: "Please sign in first",
    });
  }

  setFlash(req, "error", "Please sign in first");
  const nextUrl = encodeURIComponent(req.originalUrl);
  return res.redirect(`/login?next=${nextUrl}`);
}

function renderDenied(req, res, message) {
  if (wantsJson(req)) {
    return res.status(403).json({ message });
  }

  return res.status(403).render("error", {
    title: "Not allowed",
    statusCode: 403,
    message,
    detail: null,
  });
}

function requireAdmin(req, res, next) {
  if (!req.user) {
    return requireAuth(req, res, next);
  }

  if (req.user.role === "admin") {
    return next();
  }

  return renderDenied(req, res, "You do not have access to the admin area");
}

function requireOwnerOrAdmin(getOwnerId) {
  return async function ownerOrAdmin(req, res, next) {
    try {
      if (!req.user) {
        return requireAuth(req, res, next);
      }

      if (req.user.role === "admin") {
        return next();
      }

      const ownerId = await getOwnerId(req);

      if (ownerId && String(ownerId) === req.user._id.toString()) {
        return next();
      }

      return renderDenied(req, res, "You cannot modify this record");
    } catch (error) {
      next(error);
    }
  };
}

function redirectIfAuthenticated(req, res, next) {
  if (req.user) {
    return res.redirect("/");
  }

  next();
}

function safeNext(value, fallback = "/") {
  if (
    typeof value !== "string" ||
    !value.startsWith("/") ||
    value.startsWith("//")
  ) {
    return fallback;
  }

  return value;
}

module.exports = {
  loadUser,
  requireAuth,
  requireAdmin,
  requireOwnerOrAdmin,
  redirectIfAuthenticated,
  safeNext,
  wantsJson,
};
