# RE:FOUND · Campus Lost & Found

A server-side web application for reporting lost items, registering found items, and reconnecting
the two. Built with Express.js, MongoDB (Mongoose) and EJS for the COMP 3810SEF group project.

---

## 1. Project info

**Project name:** RE:FOUND · Campus Lost & Found

**What it does:** students sign in, report something they lost, register something they found,
browse the two lists separately, and use a claim flow to hand an item back. Every record carries a
workflow status, a claim status (unclaimed / claimed) and a search status (not found yet / found).
The app also exposes a RESTful CRUD API that needs no authentication, as the coursework requires.

**Main features**

- Register / sign in / sign out, passwords hashed with bcrypt
- Separate **Lost items** page and **Found items** page
- Full CRUD web pages for records (owner or admin can edit / delete)
- Claim flow: `open → claimed → closed`, with reject and reopen
- Claim status (`unclaimed` / `claimed`) and search status (`unfound` / `found`), editable in the
  form and switchable with one click on the detail page
- Filters: keyword, workflow status, claim status, search status
- Overview page with live counters
- My records page with three tabs: found by me, lost by me, my claims
- RESTful CRUD API (no authentication), testable with curl
- Admin page: user list and management of every record

**Tech stack**

| Layer | Used |
| --- | --- |
| Web framework | Express.js 5 |
| Database | MongoDB Atlas + Mongoose 9 |
| Views | EJS server-side templates |
| Session | `express-session` + `connect-mongo` (sessions stored in MongoDB) |
| Passwords | `bcryptjs` |
| Security | `helmet`, `express-rate-limit`, HttpOnly cookies, CSP |
| Tests | Node.js `node:test` + `mongodb-memory-server` |

**Mapping to the course technical requirements**

| Requirement (PDF) | Where it lives |
| --- | --- |
| Express.js | `app.js`, `server.js` |
| MongoDB (Mongoose) | `config/db.js`, `models/User.js`, `models/Item.js` |
| Login / logout pages | `routes/auth.js`, `views/login.ejs`, `views/register.ejs` |
| Only authorised users reach the CRUD pages | `middleware/auth.js` (`requireAuth`) |
| CRUD pages have a logout control | `views/partials/header.ejs` (every page) |
| Create / Read / Update / Delete web pages | `routes/items.js`, `views/items/*.ejs` |
| RESTful Read | `GET /api/items`, `GET /api/items/:id` |
| RESTful Create (POST) | `POST /api/items` |
| RESTful Update (PUT) | `PUT /api/items/:id` |
| RESTful Delete | `DELETE /api/items/:id` |
| README structure | sections 1–4 of this file |

---

## 2. Group info

**Group no.:** 95

| Member | Name | SID | Main work |
| --- | --- | --- | --- |
| A | TBD | TBD | Sign-in / registration / sign-out, sessions, `User` model, auth middleware, environment |
| B | TBD | TBD | Lost & found CRUD web pages (`models/Item.js`, `routes/items.js`, `views/items/`) |
| C | TBD | TBD | RESTful CRUD API (`routes/api-items.js`, `lib/item-query.js`) |
| D | TBD | TBD | UI and CSS, claim flow, tests, README |

**Course:** COMP 3810SEF Autumn 2026

---

## 3. Project file intro

```text
comp3810sef_group95/
├── server.js               # entry point: connect MongoDB, start Express, handle shutdown
├── app.js                  # Express app: EJS, sessions, routes, 404 and error handling
├── package.json            # dependencies and npm scripts
├── .env.example            # optional environment variables template
├── config/
│   ├── env.js              # read environment variables and defaults
│   ├── db.js               # Mongoose connect / disconnect
│   └── session.js          # express-session + connect-mongo
├── models/
│   ├── User.js             # user schema, bcrypt hashing, public fields
│   └── Item.js             # item schema, shared validation, serialisation
├── middleware/
│   ├── auth.js             # loadUser, requireAuth, requireAdmin, owner check
│   └── flash.js            # EJS locals (appName, currentUser, formatDate…) and flash messages
├── lib/
│   └── item-query.js       # shared filtering / keyword query for pages and API
├── routes/
│   ├── auth.js             # sign-in, register, sign-out, /api/auth/*
│   ├── pages.js            # / (overview), /me (my records), /admin/users, /api/health
│   ├── items.js            # web CRUD + claim flow (requires sign-in)
│   └── api-items.js        # RESTful CRUD API (no sign-in, per coursework)
├── views/
│   ├── partials/           # header, footer, item row
│   ├── items/              # index, new, edit, show, _form
│   ├── home.ejs            # overview page
│   ├── me.ejs              # my records page
│   ├── login.ejs / register.ejs / admin-users.ejs / error.ejs
├── public/
│   ├── styles.css          # design system, no CSS framework
│   └── app.js              # confirm dialogs for destructive forms
├── scripts/
│   ├── seed.js             # create / reset the two demo accounts
│   ├── seed-demo.js        # six demo records
│   ├── check-env.js        # check Node, MongoDB, users, items and sessions
│   └── setup-ubuntu.sh     # environment check + install + seed
├── test/
│   ├── auth.test.js        # sign-in / session / permission tests
│   └── items.test.js       # web CRUD + RESTful API tests
└── README.md
```

| File / folder | Purpose |
| --- | --- |
| `server.js` | Program entry: connect to MongoDB, listen, handle SIGINT/SIGTERM. |
| `app.js` | Builds the Express app: EJS, helmet CSP, body parsing, static files, session, routes. |
| `package.json` | Dependencies and `start` / `seed` / `seed:demo` / `check` / `test` scripts. |
| `public/` | Static assets: one stylesheet and one small script. |
| `views/` | EJS templates. `partials/` holds the shared header, footer and row; `items/` holds the CRUD pages. |
| `models/` | Mongoose schemas. `User` handles accounts, `Item` handles records. |
| `routes/` | Routing. `items.js` is the web CRUD (sign-in required), `api-items.js` is the REST API. |
| `lib/` | Query logic shared by the web lists and the API. |
| `test/` | Integration tests; `mongodb-memory-server` starts a throwaway database. |

---

## 4. Operation guides

### 4.1 Setup and start

The database connection is a MongoDB Atlas cluster and is already configured in `config/env.js`,
so no local MongoDB and no `.env` file are needed.

```bash
node -v            # must be 20 or newer
npm install
npm start
```

Expected output:

```text
[db] MongoDB connected: ac-tqvz1jr-shard-00-02.zkbb53q.mongodb.net/comp3810sef_groupX
[server] Campus Lost & Found running at http://127.0.0.1:3000
[server] environment: development
```

Open <http://127.0.0.1:3000/>.

To override a default, create a `.env` file from `.env.example` and set any of `PORT`, `HOST`,
`MONGODB_URI`, `SESSION_SECRET`.

### 4.2 Valid login details

`npm run seed` creates two accounts (run it once):

| Role | Email | Password | Can do |
| --- | --- | --- | --- |
| Admin | `admin@campus.test` | `Admin@3810Demo` | Everything, plus user management and editing / deleting any record |
| Student | `student@campus.test` | `Student@3810Demo` | CRUD on own records, browse and claim others' records |

New accounts can also be created from the sign-in page; they are always `student`.

### 4.3 Sign in / sign out

- Sign in at `/login`; on success you land on `/` (the Overview page).
- Sign out with the button in the top-right corner; it is on every signed-in page.
- Opening `/`, `/lost`, `/found`, `/me` or `/admin/users` while signed out redirects to
  `/login?next=...`, and you return to the requested page after signing in.

### 4.4 Web CRUD: which button does what

| Operation | How |
| --- | --- |
| **Create** | On the Overview, Lost items or Found items page press **＋ Report a lost item** / **＋ Register a found item**, fill the form, press **New record**. |
| **Read** | Use the top navigation: **Lost items** (`/lost`) and **Found items** (`/found`) are two separate pages. Search by keyword or filter by status / claim status / search status. Click a row to open the detail page. |
| **Update** | On the detail page press **Edit** (only the owner or an admin sees it), change the fields, press **Save changes**. |
| **Delete** | On the detail page press **Delete record**; a confirmation dialog appears first. |

**Claim flow** (separate from the edit form):

| Step | Who | Button | Status change |
| --- | --- | --- | --- |
| 1 | Any signed-in user except the owner | **This is mine** / **I found it** | `open` → `claimed` |
| 2 | Owner or admin | **Confirm handover** | `claimed` → `closed` |
| 2' | Owner or admin | **Reject / reopen** | `claimed` → `open` |

**Claim status and search status** can be changed on the edit form, or with the
**Mark as claimed / Mark as unclaimed** and **Mark as found / Mark as not found** buttons on the
detail page.

---

## 5. RESTful CRUD API

Per the coursework these endpoints **need no authentication**, so curl works directly. Run the
commands while the server is listening on `http://127.0.0.1:3000`.

| Method | Path | Purpose |
| --- | --- | --- |
| GET | `/api` | list every endpoint |
| GET | `/api/items` | list, supports `type` / `status` / `claimStatus` / `searchStatus` / `category` / `q` / `owner` / `limit` / `skip` |
| GET | `/api/items/:id` | read one |
| POST | `/api/items` | create (201 + `Location`) |
| PUT | `/api/items/:id` | update, partial updates allowed |
| DELETE | `/api/items/:id` | delete |

### 5.1 Health check

```bash
curl -i http://127.0.0.1:3000/api/health
```

```json
{"status":"ok","database":"connected"}
```

### 5.2 Read: list

```bash
curl -i http://127.0.0.1:3000/api/items
```

```bash
curl -s "http://127.0.0.1:3000/api/items?type=found&claimStatus=unclaimed&limit=5"
```

### 5.3 Read: single record

```bash
curl -i http://127.0.0.1:3000/api/items/<ITEM_ID>
```

### 5.4 Create (POST)

```bash
curl -i \
  -H "Content-Type: application/json" \
  -d '{"title":"Black umbrella","type":"lost","category":"accessories","location":"Library","description":"White sticker on the handle"}' \
  http://127.0.0.1:3000/api/items
```

Returns `201 Created` with a `Location` header. A missing `title` or an invalid `type` returns `400`.

### 5.5 Update (PUT)

```bash
curl -i -X PUT \
  -H "Content-Type: application/json" \
  -d '{"status":"claimed"}' \
  http://127.0.0.1:3000/api/items/<ITEM_ID>
```

```bash
curl -i -X PUT \
  -H "Content-Type: application/json" \
  -d '{"claimStatus":"claimed","searchStatus":"found"}' \
  http://127.0.0.1:3000/api/items/<ITEM_ID>
```

### 5.6 Delete

```bash
curl -i -X DELETE http://127.0.0.1:3000/api/items/<ITEM_ID>
```

```json
{"message":"Deleted","deleted":{"id":"6730a1f2c9e4b80012ab34cd","title":"Black umbrella"}}
```

### 5.7 Auth-related endpoints

| Method | Path | Purpose |
| --- | --- | --- |
| GET | `/api/auth/me` | current user, 401 when signed out |
| POST | `/api/auth/login` | JSON sign-in, sets the cookie |
| POST | `/api/auth/register` | JSON registration, signs in automatically |
| POST | `/api/auth/logout` | sign out |

---

## 6. Automated tests

```bash
npm test
```

The suite starts a throwaway MongoDB through `mongodb-memory-server`, so the Atlas cluster is not
touched. 60 tests in two files:

- `test/auth.test.js` — redirects and 401s, sign-in / register / sign-out, 403 on the admin page,
  the 429 rate limit.
- `test/items.test.js` — web CRUD, validation errors, the separate lost / found lists, owner and
  admin permissions, the claim flow, claim status / search status, and every REST endpoint.

---

## 7. Submission checklist

- Folder name: `comp3810sef_group95`
- Archive name: `comp3810sef_group95.zip`
- Remove `node_modules/` and any local `.env` before zipping
- Fill in the member names and SIDs in section 2
