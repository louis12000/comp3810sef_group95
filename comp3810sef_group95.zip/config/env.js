const path = require("path");

require("dotenv").config({
  path: path.join(__dirname, "..", ".env"),
  quiet: true,
});

function toInteger(value, fallback, name, min, max) {
  const number = Number(value ?? fallback);

  if (!Number.isInteger(number) || number < min || number > max) {
    throw new Error(`${name} must be an integer between ${min} and ${max}`);
  }

  return number;
}

const env = {
  NODE_ENV: process.env.NODE_ENV || "development",
  PORT: toInteger(process.env.PORT, 3000, "PORT", 1, 65535),
  HOST: process.env.HOST || "0.0.0.0",

  MONGODB_URI:
    process.env.MONGODB_URI ||
    "mongodb+srv://s1444536_db_user:1245abcd@cluster0.zkbb53q.mongodb.net/comp3810sef_groupX",

  SESSION_SECRET:
    process.env.SESSION_SECRET ||
    "comp3810sef-course-demo-fixed-secret-0123456789abcdef",
  SESSION_MAX_AGE_MS: toInteger(
    process.env.SESSION_MAX_AGE_MS,
    60 * 60 * 1000,
    "SESSION_MAX_AGE_MS",
    60 * 1000,
    30 * 24 * 60 * 60 * 1000
  ),
  SESSION_COOKIE_NAME: "comp3810.sid",
  COOKIE_SECURE: process.env.COOKIE_SECURE === "true",
  TRUST_PROXY: process.env.TRUST_PROXY === "1",

  SEED_ADMIN_NAME: process.env.SEED_ADMIN_NAME || "System Administrator",
  SEED_ADMIN_EMAIL: (
    process.env.SEED_ADMIN_EMAIL || "admin@campus.test"
  ).toLowerCase(),
  SEED_ADMIN_PASSWORD: process.env.SEED_ADMIN_PASSWORD || "Admin@3810Demo",

  SEED_USER_NAME: process.env.SEED_USER_NAME || "Demo Student",
  SEED_USER_EMAIL: (
    process.env.SEED_USER_EMAIL || "student@campus.test"
  ).toLowerCase(),
  SEED_USER_PASSWORD: process.env.SEED_USER_PASSWORD || "Student@3810Demo",
};

if (!/^mongodb(\+srv)?:\/\//.test(env.MONGODB_URI)) {
  throw new Error("MONGODB_URI must start with mongodb:// or mongodb+srv://");
}

if (env.NODE_ENV === "production" && !env.COOKIE_SECURE) {
  throw new Error(
    "Set COOKIE_SECURE=true and serve the app over HTTPS in production"
  );
}

module.exports = env;
