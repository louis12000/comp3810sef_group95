const express = require("express");
const mongoose = require("mongoose");

const Item = require("../models/Item");
const {
  CATEGORY_LABELS,
  CLAIM_STATUSES,
  CLAIM_STATUS_LABELS,
  ITEM_CATEGORIES,
  ITEM_STATUSES,
  ITEM_TYPES,
  SEARCH_STATUSES,
  SEARCH_STATUS_LABELS,
  STATUS_LABELS,
  TYPE_LABELS,
} = require("../models/Item");
const { requireAuth } = require("../middleware/auth");
const { setFlash } = require("../middleware/flash");
const { asString, buildItemFilter } = require("../lib/item-query");

const router = express.Router();

const LIST_LIMIT = 100;

const meta = {
  types: ITEM_TYPES.map((value) => ({ value, label: TYPE_LABELS[value] })),
  statuses: ITEM_STATUSES.map((value) => ({
    value,
    label: STATUS_LABELS[value],
  })),
  claimStatuses: CLAIM_STATUSES.map((value) => ({
    value,
    label: CLAIM_STATUS_LABELS[value],
  })),
  searchStatuses: SEARCH_STATUSES.map((value) => ({
    value,
    label: SEARCH_STATUS_LABELS[value],
  })),
  categories: ITEM_CATEGORIES.map((value) => ({
    value,
    label: CATEGORY_LABELS[value],
  })),
  typeLabel: TYPE_LABELS,
  statusLabel: STATUS_LABELS,
  claimStatusLabel: CLAIM_STATUS_LABELS,
  searchStatusLabel: SEARCH_STATUS_LABELS,
  categoryLabel: CATEGORY_LABELS,
};

function todayInputValue() {
  const now = new Date();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  return `${now.getFullYear()}-${month}-${day}`;
}

function renderNotFound(req, res) {
  return res.status(404).render("error", {
    title: "Item not found",
    statusCode: 404,
    message: "That lost & found record does not exist.",
    detail: null,
  });
}

function renderForbidden(req, res, message) {
  return res.status(403).render("error", {
    title: "Not allowed",
    statusCode: 403,
    message,
    detail: null,
  });
}

function formValues(body) {
  const input = body && typeof body === "object" ? body : {};

  return {
    title: asString(input.title),
    description: asString(input.description),
    type: ITEM_TYPES.includes(asString(input.type)) ? input.type : "lost",
    category: ITEM_CATEGORIES.includes(asString(input.category))
      ? input.category
      : "other",
    location: asString(input.location),
    occurredAt: asString(input.occurredAt) || todayInputValue(),
    claimMessage: asString(input.claimMessage),
    claimStatus: CLAIM_STATUSES.includes(asString(input.claimStatus))
      ? input.claimStatus
      : "unclaimed",
    searchStatus: SEARCH_STATUSES.includes(asString(input.searchStatus))
      ? input.searchStatus
      : "unfound",
  };
}

function parseListQuery(query) {
  const source = query && typeof query === "object" ? query : {};
  const status = ITEM_STATUSES.includes(asString(source.status))
    ? source.status
    : "all";
  const claimStatus = CLAIM_STATUSES.includes(asString(source.claimStatus))
    ? source.claimStatus
    : "all";
  const searchStatus = SEARCH_STATUSES.includes(asString(source.searchStatus))
    ? source.searchStatus
    : "all";
  const q = asString(source.q).trim().slice(0, 60);

  return { status, claimStatus, searchStatus, q };
}

async function loadItem(req, res, next) {
  try {
    const { id } = req.params;

    if (!mongoose.isValidObjectId(id)) {
      return renderNotFound(req, res);
    }

    const item = await Item.findById(id)
      .populate("owner", "name email")
      .populate("claimedBy", "name email");

    if (!item) {
      return renderNotFound(req, res);
    }

    req.item = item;
    next();
  } catch (error) {
    next(error);
  }
}

function requireManageable(req, res, next) {
  if (Item.isOwnerOrAdmin(req.item, req.user)) {
    return next();
  }

  return renderForbidden(
    req,
    res,
    "Only the owner or an admin can modify this record"
  );
}

async function renderList(req, res, next, type) {
  try {
    const filters = parseListQuery(req.query);
    const { filter: query } = buildItemFilter({ ...filters, type });

    const [items, total] = await Promise.all([
      Item.find(query)
        .sort({ createdAt: -1 })
        .limit(LIST_LIMIT)
        .populate("owner", "name email")
        .populate("claimedBy", "name email"),
      Item.countDocuments(query),
    ]);

    return res.render("items/index", {
      title: type === "lost" ? "Lost items" : "Found items",
      listType: type,
      items,
      total,
      filters,
      meta,
      truncated: total > items.length,
    });
  } catch (error) {
    return next(error);
  }
}

router.get("/items", requireAuth, (req, res) => res.redirect("/lost"));

router.get("/lost", requireAuth, (req, res, next) =>
  renderList(req, res, next, "lost")
);

router.get("/found", requireAuth, (req, res, next) =>
  renderList(req, res, next, "found")
);

router.get("/items/new", requireAuth, (req, res) => {
  const requestedType = asString(req.query.type);

  res.render("items/new", {
    title: "New record",
    meta,
    errors: {},
    values: {
      title: "",
      description: "",
      type: ITEM_TYPES.includes(requestedType) ? requestedType : "lost",
      category: "other",
      location: "",
      occurredAt: todayInputValue(),
      claimMessage: "",
      claimStatus: "unclaimed",
      searchStatus: "unfound",
    },
  });
});

router.post("/items", requireAuth, async (req, res, next) => {
  try {
    const result = Item.validatePayload(req.body || {}, "create");

    if (!result.ok) {
      return res.status(400).render("items/new", {
        title: "New record",
        meta,
        errors: result.errors,
        values: formValues(req.body),
      });
    }

    const item = await Item.create({
      ...result.values,
      owner: req.user._id,
    });

    setFlash(req, "success", "Record created");
    return res.redirect(`/items/${item._id}`);
  } catch (error) {
    next(error);
  }
});

router.get("/items/:id", requireAuth, loadItem, (req, res) => {
  const item = req.item;

  res.render("items/show", {
    title: item.title,
    item,
    meta,
    canManage: Item.isOwnerOrAdmin(item, req.user),
    canClaim:
      item.status === "open" &&
      Boolean(item.owner) &&
      String(item.owner._id) !== String(req.user._id),
  });
});

router.get(
  "/items/:id/edit",
  requireAuth,
  loadItem,
  requireManageable,
  (req, res) => {
    const item = req.item;

    res.render("items/edit", {
      title: "Edit record",
      item,
      meta,
      errors: {},
      values: {
        title: item.title,
        description: item.description,
        type: item.type,
        category: item.category,
        location: item.location,
        occurredAt: item.occurredAt
          ? new Date(item.occurredAt).toISOString().slice(0, 10)
          : "",
        claimMessage: item.claimMessage,
        claimStatus: item.claimStatus,
        searchStatus: item.searchStatus,
      },
    });
  }
);

router.post(
  "/items/:id",
  requireAuth,
  loadItem,
  requireManageable,
  async (req, res, next) => {
    try {
      const result = Item.validatePayload(req.body || {}, "update");

      if (!result.ok) {
        return res.status(400).render("items/edit", {
          title: "Edit record",
          item: req.item,
          meta,
          errors: result.errors,
          values: formValues(req.body),
        });
      }

      delete result.values.status;

      Object.assign(req.item, result.values);
      await req.item.save();

      setFlash(req, "success", "Record updated");
      return res.redirect(`/items/${req.item._id}`);
    } catch (error) {
      next(error);
    }
  }
);

router.post(
  "/items/:id/delete",
  requireAuth,
  loadItem,
  requireManageable,
  async (req, res, next) => {
    try {
      const { title, type } = req.item;
      await req.item.deleteOne();

      setFlash(req, "success", `Deleted "${title}"`);
      return res.redirect(`/${type}`);
    } catch (error) {
      next(error);
    }
  }
);

router.post(
  "/items/:id/claim",
  requireAuth,
  loadItem,
  async (req, res, next) => {
    try {
      const item = req.item;

      if (item.owner && String(item.owner._id) === String(req.user._id)) {
        setFlash(req, "error", "You cannot claim your own record");
        return res.redirect(`/items/${item._id}`);
      }

      if (item.status !== "open") {
        setFlash(req, "error", "This record is already being handled");
        return res.redirect(`/items/${item._id}`);
      }

      item.status = "claimed";
      item.claimedBy = req.user._id;
      item.claimMessage = asString(req.body && req.body.claimMessage)
        .trim()
        .slice(0, 500);
      item.claimedAt = new Date();
      await item.save();

      setFlash(req, "success", "Claim submitted - waiting for confirmation");
      return res.redirect(`/items/${item._id}`);
    } catch (error) {
      next(error);
    }
  }
);

router.post(
  "/items/:id/confirm",
  requireAuth,
  loadItem,
  requireManageable,
  async (req, res, next) => {
    try {
      const item = req.item;

      if (item.status !== "claimed") {
        setFlash(
          req,
          "error",
          "Only records with a pending claim can be confirmed"
        );
        return res.redirect(`/items/${item._id}`);
      }

      item.status = "closed";
      item.closedAt = new Date();
      item.claimStatus = "claimed";
      item.searchStatus = "found";
      await item.save();

      setFlash(req, "success", "Handover confirmed - record closed");
      return res.redirect(`/items/${item._id}`);
    } catch (error) {
      next(error);
    }
  }
);

router.post(
  "/items/:id/reopen",
  requireAuth,
  loadItem,
  requireManageable,
  async (req, res, next) => {
    try {
      const item = req.item;

      if (item.status === "open") {
        setFlash(req, "error", "This record is already open");
        return res.redirect(`/items/${item._id}`);
      }

      item.status = "open";
      item.claimedBy = null;
      item.claimMessage = "";
      item.claimedAt = null;
      item.closedAt = null;
      item.claimStatus = "unclaimed";
      item.searchStatus = "unfound";
      await item.save();

      setFlash(req, "success", "Record reopened");
      return res.redirect(`/items/${item._id}`);
    } catch (error) {
      next(error);
    }
  }
);

router.post(
  "/items/:id/claim-status",
  requireAuth,
  loadItem,
  requireManageable,
  async (req, res, next) => {
    try {
      const nextStatus = asString(req.body && req.body.claimStatus).trim();

      if (!CLAIM_STATUSES.includes(nextStatus)) {
        setFlash(req, "error", "Unknown claim status");
        return res.redirect(`/items/${req.item._id}`);
      }

      req.item.claimStatus = nextStatus;
      await req.item.save();

      setFlash(
        req,
        "success",
        `Claim status updated: ${CLAIM_STATUS_LABELS[nextStatus]}`
      );
      return res.redirect(`/items/${req.item._id}`);
    } catch (error) {
      next(error);
    }
  }
);

router.post(
  "/items/:id/search-status",
  requireAuth,
  loadItem,
  requireManageable,
  async (req, res, next) => {
    try {
      const nextStatus = asString(req.body && req.body.searchStatus).trim();

      if (!SEARCH_STATUSES.includes(nextStatus)) {
        setFlash(req, "error", "Unknown search status");
        return res.redirect(`/items/${req.item._id}`);
      }

      req.item.searchStatus = nextStatus;
      await req.item.save();

      setFlash(
        req,
        "success",
        `Search status updated: ${SEARCH_STATUS_LABELS[nextStatus]}`
      );
      return res.redirect(`/items/${req.item._id}`);
    } catch (error) {
      next(error);
    }
  }
);

module.exports = router;
module.exports.meta = meta;
