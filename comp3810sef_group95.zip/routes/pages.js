const express = require("express");
const mongoose = require("mongoose");

const User = require("../models/User");
const Item = require("../models/Item");
const itemRoutes = require("./items");
const { requireAdmin, requireAuth } = require("../middleware/auth");

const router = express.Router();

const meta = itemRoutes.meta;

const RECORD_TABS = ["found", "lost", "claims"];

function withStatusDefaults(item) {
  return {
    ...item,
    claimStatus: item.claimStatus || "unclaimed",
    searchStatus: item.searchStatus || "unfound",
  };
}

router.get("/", async (req, res, next) => {
  if (!req.user) {
    return res.redirect("/login");
  }

  try {
    const myId = req.user._id;

    const [
      unclaimedFound,
      claimedTotal,
      recovered,
      myUnclaimed,
      totalFound,
      recent,
      available,
    ] = await Promise.all([
      Item.countDocuments({ type: "found", claimStatus: "unclaimed" }),
      Item.countDocuments({ claimStatus: "claimed" }),
      Item.countDocuments({ searchStatus: "found" }),
      Item.countDocuments({ owner: myId, claimStatus: "unclaimed" }),
      Item.countDocuments({ type: "found" }),
      Item.find({ type: "found" })
        .sort({ createdAt: -1 })
        .limit(4)
        .populate("owner", "name email")
        .lean(),
      Item.find({ type: "found", claimStatus: "unclaimed" })
        .sort({ createdAt: -1 })
        .limit(4)
        .populate("owner", "name email")
        .lean(),
    ]);

    return res.render("home", {
      title: "Overview",
      meta,
      stats: {
        unclaimedFound,
        claimedTotal,
        recovered,
        myUnclaimed,
        totalFound,
      },
      recent: recent.map(withStatusDefaults),
      available: available.map(withStatusDefaults),
    });
  } catch (error) {
    return next(error);
  }
});

router.get("/me", requireAuth, async (req, res, next) => {
  try {
    const myId = req.user._id;
    const requested = String(req.query.tab || "");
    const tab = RECORD_TABS.includes(requested) ? requested : "found";

    const [foundItems, lostItems, claims] = await Promise.all([
      Item.find({ owner: myId, type: "found" })
        .sort({ createdAt: -1 })
        .populate("owner", "name email")
        .lean(),
      Item.find({ owner: myId, type: "lost" })
        .sort({ createdAt: -1 })
        .populate("owner", "name email")
        .lean(),
      Item.find({ claimedBy: myId })
        .sort({ claimedAt: -1 })
        .populate("owner", "name email")
        .populate("claimedBy", "name email")
        .lean(),
    ]);

    const list = (
      tab === "found" ? foundItems : tab === "lost" ? lostItems : claims
    ).map(withStatusDefaults);

    return res.render("me", {
      title: "My records",
      meta,
      tab,
      list,
      counts: {
        found: foundItems.length,
        lost: lostItems.length,
        claims: claims.length,
        unfoundLost: lostItems.filter(
          (item) => (item.searchStatus || "unfound") === "unfound"
        ).length,
      },
    });
  } catch (error) {
    return next(error);
  }
});

router.get("/dashboard", requireAuth, (req, res) => res.redirect("/"));

router.get("/admin", requireAuth, requireAdmin, (req, res) => {
  res.redirect("/admin/users");
});

router.get(
  "/admin/users",
  requireAuth,
  requireAdmin,
  async (req, res, next) => {
    try {
      const users = await User.find()
        .select("name email role isActive createdAt lastLoginAt")
        .sort({ createdAt: 1 })
        .lean();

      res.render("admin-users", {
        title: "User management",
        users,
      });
    } catch (error) {
      next(error);
    }
  }
);

router.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    database:
      mongoose.connection.readyState === 1 ? "connected" : "disconnected",
  });
});

module.exports = router;
