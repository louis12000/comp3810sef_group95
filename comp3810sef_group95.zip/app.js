const path = require("path");

const express = require("express");
const helmet = require("helmet");

const env = require("./config/env");
const { createSessionMiddleware } = require("./config/session");
const { loadUser, wantsJson } = require("./middleware/auth");
const { exposeLocals } = require("./middleware/flash");
const authRoutes = require("./routes/auth");
const pageRoutes = require("./routes/pages");
const itemRoutes = require("./routes/items");
const apiItemRoutes = require("./routes/api-items");

function createApp() {
  const app = express();

  app.disable("x-powered-by");

  if (env.TRUST_PROXY) {
    app.set("trust proxy", 1);
  }

  app.set("view engine", "ejs");
  app.set("views", path.join(__dirname, "views"));

  app.use(
    helmet({
      contentSecurityPolicy: {
        directives: {
          "upgrade-insecure-requests":
            env.NODE_ENV === "production" ? [] : null,
        },
      },
    })
  );

  app.use(express.json({ limit: "32kb" }));
  app.use(express.urlencoded({ extended: false, limit: "32kb" }));
  app.use(express.static(path.join(__dirname, "public")));

  app.use(createSessionMiddleware());
  app.use(loadUser);
  app.use(exposeLocals);

  app.use(authRoutes);
  app.use(pageRoutes);
  app.use(itemRoutes);
  app.use(apiItemRoutes);

  app.use((req, res) => {
    if (wantsJson(req)) {
      return res.status(404).json({
        message: "Resource not found",
      });
    }

    return res.status(404).render("error", {
      title: "Page not found",
      statusCode: 404,
      message: "This page does not exist.",
      detail: null,
    });
  });

  app.use((error, req, res, next) => {
    if (res.headersSent) {
      return next(error);
    }

    console.error(error);

    let statusCode = 500;
    let message = "Server error";

    if (error.type === "entity.parse.failed") {
      statusCode = 400;
      message = "Malformed JSON body";
    } else if (error.type === "entity.too.large") {
      statusCode = 413;
      message = "Request body too large";
    } else if (error.name === "ValidationError") {
      statusCode = 400;
      message = "Invalid input";
    }

    res.locals.currentUser = res.locals.currentUser || null;
    res.locals.flash = res.locals.flash || null;
    res.locals.currentPath = req.path;

    if (wantsJson(req)) {
      return res.status(statusCode).json({ message });
    }

    return res.status(statusCode).render("error", {
      title: "Something went wrong",
      statusCode,
      message,
      detail: env.NODE_ENV === "development" ? error.stack : null,
    });
  });

  return app;
}

module.exports = createApp;
